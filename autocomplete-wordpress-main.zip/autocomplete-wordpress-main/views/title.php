<div class="centered autocomplete-box-header">
  <h2><?php esc_html_e( constant("AUTOCOMPLETE_DESCRIPTION"), 'autocomplete' ); ?></h2>
</div>