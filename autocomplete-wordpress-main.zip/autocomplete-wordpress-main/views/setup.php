<div class="autocomplete-setup-instructions">
  <p><?php esc_html_e( 'Enter your AutoComplete API key to begin.', 'autocomplete' ); ?></p>
  <p>Visit <a href="<?php echo autocomplete_url('dashboard/account'); ?>" target="_blank">the dashboard</a> to access your API key.
</div>
